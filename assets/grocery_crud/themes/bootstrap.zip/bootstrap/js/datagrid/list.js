/*global jQuery*/
jQuery(function ($) {

    "use strict";

    //As simple as that! :)
    $('.gc-container').datagrid();

});